package app.io;

public interface Writer {
    void write(String text);
    void writeLine(String text);
}
