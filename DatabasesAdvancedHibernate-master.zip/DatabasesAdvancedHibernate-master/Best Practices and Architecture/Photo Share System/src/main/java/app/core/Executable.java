package app.core;

public interface Executable {

    String Execute();
}
