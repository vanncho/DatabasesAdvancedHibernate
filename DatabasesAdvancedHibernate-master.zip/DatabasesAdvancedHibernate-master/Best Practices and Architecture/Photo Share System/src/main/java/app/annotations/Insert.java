package app.annotations;

public @interface Insert {
}
