package app.domains.enumerations;

public enum Color {
    WHITE,
    GREEN,
    BLUE,
    PINK,
    YELLOW,
    BLACK,
    CYAN,
    MEGENTA,
    RED,
    PURPLE,
    WHITE_BLACK_GRADIENT
}
