package app.io;

public interface Reader {
    String readLine();
}
