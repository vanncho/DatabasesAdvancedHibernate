package app.domains.enumerations;

public enum Role {
    OWNER,
    VIEWER
}
