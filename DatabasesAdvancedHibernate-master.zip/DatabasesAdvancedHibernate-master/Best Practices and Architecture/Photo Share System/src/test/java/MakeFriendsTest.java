public class MakeFriendsTest {

}
