public class UploadProfilePictureTest {

}
